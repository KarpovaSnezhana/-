from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import Http404, HttpResponseRedirect
from django.urls import reverse

#from .models import Task

def index(request):
    return render(request, 'index/index.html')